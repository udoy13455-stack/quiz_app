package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String PREF_NAME = "MCAQuizLocalStore";
    private static final String KEY_USERS_JSON = "users_json";
    private static final String KEY_ACTIVE_USER = "active_user";

    private static final String CAT_DS = "MCA: Advanced Data Structures";
    private static final String CAT_ANDROID = "MCA: Android App Development";
    private static final String CAT_CYBER = "MCA: Cyber Security & Crypto";
    private static final String CAT_ALL = "All MCA Modules Mixed";

    // Containers & Header
    private LinearLayout layoutHeaderBanner, logoBadgeContainer;
    private LinearLayout layoutAuth, layoutDashboard, layoutQuiz, layoutResult, cardUserProfile;
    private ImageView ivAppLogo;

    // Auth Views
    private TextView tvAuthTitle, tvAuthSubtitle;
    private EditText etFullName, etUsername, etPassword, etConfirmPassword;
    private Button btnAuthSubmit, btnToggleAuthMode;
    private boolean isSignupMode = false;

    // Dashboard Views
    private TextView tvWelcomeUser, tvBestScoreStats;
    private Button btnCatDataStructures, btnCatAndroid, btnCatCyberSecurity, btnCatAllMixed, btnLogout;

    // Quiz Views
    private TextView tvQuizCategory, tvQuestionProgress, tvQuestionText;
    private ProgressBar progressBarQuiz;
    private RadioGroup rgOptions;
    private RadioButton rbOptionA, rbOptionB, rbOptionC, rbOptionD;
    private Button btnNextQuestion, btnQuitQuiz;

    // Result Views
    private TextView tvResultScore, tvResultSummary;
    private Button btnRetryQuiz, btnBackToDashboard;

    // State
    private SharedPreferences sharedPreferences;
    private String currentUsername = null;
    private String selectedCategory = CAT_DS;
    private final List<Question> allQuestions = new ArrayList<>();
    private final List<Question> activeQuizQuestions = new ArrayList<>();
    private int currentQuestionIndex = 0;
    private int currentScore = 0;
    private StringBuilder answerReviewBuilder = new StringBuilder();

    private static class Question {
        final String category;
        final String questionText;
        final String[] options;
        final int correctAnswerIndex;
        final String explanation;

        Question(String category, String questionText, String[] options, int correctAnswerIndex, String explanation) {
            this.category = category;
            this.questionText = questionText;
            this.options = options;
            this.correctAnswerIndex = correctAnswerIndex;
            this.explanation = explanation;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        initViews();
        applyModernAttractiveStyling();
        renderCustomMcaLogo();
        loadMcaQuestionBank();
        setupListeners();

        // Restore active user session from SharedPreferences
        String savedUser = sharedPreferences.getString(KEY_ACTIVE_USER, null);
        if (savedUser != null && userExists(savedUser)) {
            currentUsername = savedUser;
            showDashboard();
        } else {
            showAuthScreen();
        }
    }

    private void initViews() {
        layoutHeaderBanner = findViewById(R.id.layoutHeaderBanner);
        logoBadgeContainer = findViewById(R.id.logoBadgeContainer);
        ivAppLogo = findViewById(R.id.ivAppLogo);

        layoutAuth = findViewById(R.id.layoutAuth);
        layoutDashboard = findViewById(R.id.layoutDashboard);
        layoutQuiz = findViewById(R.id.layoutQuiz);
        layoutResult = findViewById(R.id.layoutResult);
        cardUserProfile = findViewById(R.id.cardUserProfile);

        tvAuthTitle = findViewById(R.id.tvAuthTitle);
        tvAuthSubtitle = findViewById(R.id.tvAuthSubtitle);
        etFullName = findViewById(R.id.etFullName);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnAuthSubmit = findViewById(R.id.btnAuthSubmit);
        btnToggleAuthMode = findViewById(R.id.btnToggleAuthMode);

        tvWelcomeUser = findViewById(R.id.tvWelcomeUser);
        tvBestScoreStats = findViewById(R.id.tvBestScoreStats);
        btnCatDataStructures = findViewById(R.id.btnCatDataStructures);
        btnCatAndroid = findViewById(R.id.btnCatAndroid);
        btnCatCyberSecurity = findViewById(R.id.btnCatCyberSecurity);
        btnCatAllMixed = findViewById(R.id.btnCatAllMixed);
        btnLogout = findViewById(R.id.btnLogout);

        tvQuizCategory = findViewById(R.id.tvQuizCategory);
        tvQuestionProgress = findViewById(R.id.tvQuestionProgress);
        tvQuestionText = findViewById(R.id.tvQuestionText);
        progressBarQuiz = findViewById(R.id.progressBarQuiz);
        rgOptions = findViewById(R.id.rgOptions);
        rbOptionA = findViewById(R.id.rbOptionA);
        rbOptionB = findViewById(R.id.rbOptionB);
        rbOptionC = findViewById(R.id.rbOptionC);
        rbOptionD = findViewById(R.id.rbOptionD);
        btnNextQuestion = findViewById(R.id.btnNextQuestion);
        btnQuitQuiz = findViewById(R.id.btnQuitQuiz);

        tvResultScore = findViewById(R.id.tvResultScore);
        tvResultSummary = findViewById(R.id.tvResultSummary);
        btnRetryQuiz = findViewById(R.id.btnRetryQuiz);
        btnBackToDashboard = findViewById(R.id.btnBackToDashboard);
    }

    // Programmatically creates gradients, rounded cards, and custom MCA graduation-cap + shield logo
    private void applyModernAttractiveStyling() {
        // Gradient Hero Header Banner
        GradientDrawable bannerGradient = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#1E1B4B"), Color.parseColor("#4338CA"), Color.parseColor("#6D28D9")}
        );
        bannerGradient.setCornerRadius(dpToPx(22));
        layoutHeaderBanner.setBackground(bannerGradient);

        // Circular Glowing Badge behind Logo
        GradientDrawable circleLogoBg = new GradientDrawable();
        circleLogoBg.setShape(GradientDrawable.OVAL);
        circleLogoBg.setColor(Color.parseColor("#312E81"));
        circleLogoBg.setStroke(dpToPx(2), Color.parseColor("#A5B4FC"));
        logoBadgeContainer.setBackground(circleLogoBg);

        // Rounded Elevated White Cards
        layoutAuth.setBackground(createRoundedCard(Color.WHITE, 20, Color.parseColor("#E0E7FF")));
        cardUserProfile.setBackground(createRoundedCard(Color.WHITE, 18, Color.parseColor("#C7D2FE")));
        layoutQuiz.setBackground(createRoundedCard(Color.WHITE, 20, Color.parseColor("#E0E7FF")));
        layoutResult.setBackground(createRoundedCard(Color.WHITE, 20, Color.parseColor("#E0E7FF")));

        // Modern Styled Input Fields
        etFullName.setBackground(createInputBox());
        etUsername.setBackground(createInputBox());
        etPassword.setBackground(createInputBox());
        etConfirmPassword.setBackground(createInputBox());

        // Styled Radio Option Cards
        styleOptionRadioButton(rbOptionA);
        styleOptionRadioButton(rbOptionB);
        styleOptionRadioButton(rbOptionC);
        styleOptionRadioButton(rbOptionD);
    }

    // Draws a crisp MCA Academic Cap + Hexagon Emblem directly onto the ImageView (no external PNG required)
    private void renderCustomMcaLogo() {
        int size = 160;
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Draw Graduation Mortarboard Cap Diamond
        paint.setColor(Color.parseColor("#FACC15")); // Gold accent
        paint.setStyle(Paint.Style.FILL);
        Path capTop = new Path();
        capTop.moveTo(size * 0.50f, size * 0.14f);
        capTop.lineTo(size * 0.90f, size * 0.34f);
        capTop.lineTo(size * 0.50f, size * 0.54f);
        capTop.lineTo(size * 0.10f, size * 0.34f);
        capTop.close();
        canvas.drawPath(capTop, paint);

        // Tassel on left
        paint.setStrokeWidth(6f);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawLine(size * 0.22f, size * 0.38f, size * 0.18f, size * 0.64f, paint);

        // Draw "MCA" Badge Pill below cap
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        RectF badgeRect = new RectF(size * 0.18f, size * 0.58f, size * 0.82f, size * 0.86f);
        canvas.drawRoundRect(badgeRect, 18f, 18f, paint);

        // Draw "MCA" Text inside Pill
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.parseColor("#1E1B4B"));
        textPaint.setTextSize(30f);
        textPaint.setFakeBoldText(true);
        textPaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("MCA", size * 0.50f, size * 0.79f, textPaint);

        ivAppLogo.setImageTintList(null);
        ivAppLogo.setImageBitmap(bmp);
    }

    private GradientDrawable createRoundedCard(int bgColor, int radiusDp, int strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(bgColor);
        drawable.setCornerRadius(dpToPx(radiusDp));
        drawable.setStroke(dpToPx(1), strokeColor);
        return drawable;
    }

    private GradientDrawable createInputBox() {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(Color.parseColor("#F8FAFC"));
        drawable.setCornerRadius(dpToPx(12));
        drawable.setStroke(dpToPx(1), Color.parseColor("#CBD5E1"));
        return drawable;
    }

    private void styleOptionRadioButton(RadioButton rb) {
        rb.setBackground(createRoundedCard(Color.parseColor("#F8FAFC"), 12, Color.parseColor("#CBD5E1")));
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private void setupListeners() {
        btnToggleAuthMode.setOnClickListener(v -> {
            isSignupMode = !isSignupMode;
            updateAuthModeUI();
        });

        btnAuthSubmit.setOnClickListener(v -> {
            if (isSignupMode) {
                handleSignUp();
            } else {
                handleLogin();
            }
        });

        btnCatDataStructures.setOnClickListener(v -> startQuiz(CAT_DS));
        btnCatAndroid.setOnClickListener(v -> startQuiz(CAT_ANDROID));
        btnCatCyberSecurity.setOnClickListener(v -> startQuiz(CAT_CYBER));
        btnCatAllMixed.setOnClickListener(v -> startQuiz(CAT_ALL));

        btnLogout.setOnClickListener(v -> {
            sharedPreferences.edit().remove(KEY_ACTIVE_USER).apply();
            currentUsername = null;
            clearAuthInputs();
            showAuthScreen();
            Toast.makeText(this, "Signed out of MCA Portal", Toast.LENGTH_SHORT).show();
        });

        btnNextQuestion.setOnClickListener(v -> processAnswerAndAdvance());
        btnQuitQuiz.setOnClickListener(v -> showDashboard());

        btnRetryQuiz.setOnClickListener(v -> startQuiz(selectedCategory));
        btnBackToDashboard.setOnClickListener(v -> showDashboard());
    }

    // ==================== AUTHENTICATION WITH LOCAL STORAGE ====================

    private void updateAuthModeUI() {
        if (isSignupMode) {
            tvAuthTitle.setText("Create MCA Student Account");
            etFullName.setVisibility(View.VISIBLE);
            etConfirmPassword.setVisibility(View.VISIBLE);
            btnAuthSubmit.setText("Register & Start MCA Quiz");
            btnToggleAuthMode.setText("Already registered? Login here");
        } else {
            tvAuthTitle.setText("Welcome Back!");
            etFullName.setVisibility(View.GONE);
            etConfirmPassword.setVisibility(View.GONE);
            btnAuthSubmit.setText("Login to MCA Portal");
            btnToggleAuthMode.setText("New MCA Student? Create Account");
        }
    }

    private void handleSignUp() {
        String fullName = etFullName.getText().toString().trim();
        String username = etUsername.getText().toString().trim().toLowerCase(Locale.ROOT);
        String password = etPassword.getText().toString();
        String confirmPass = etConfirmPassword.getText().toString();

        if (TextUtils.isEmpty(fullName)) {
            etFullName.setError("Full name is required");
            return;
        }
        if (TextUtils.isEmpty(username) || username.length() < 3) {
            etUsername.setError("Username must be at least 3 characters");
            return;
        }
        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            return;
        }
        if (!password.equals(confirmPass)) {
            etConfirmPassword.setError("Passwords do not match");
            return;
        }

        try {
            JSONObject usersRoot = getUsersJsonObject();
            if (usersRoot.has(username)) {
                etUsername.setError("Username already exists");
                return;
            }

            String salt = generateSalt();
            String passwordHash = hashPassword(password, salt);

            JSONObject userObj = new JSONObject();
            userObj.put("fullName", fullName);
            userObj.put("salt", salt);
            userObj.put("passwordHash", passwordHash);
            userObj.put("bestPercentage", 0);
            userObj.put("quizzesPlayed", 0);

            usersRoot.put(username, userObj);
            sharedPreferences.edit()
                    .putString(KEY_USERS_JSON, usersRoot.toString())
                    .putString(KEY_ACTIVE_USER, username)
                    .apply();

            currentUsername = username;
            clearAuthInputs();
            Toast.makeText(this, "MCA Account created!", Toast.LENGTH_SHORT).show();
            showDashboard();

        } catch (JSONException e) {
            Toast.makeText(this, "Local storage error", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleLogin() {
        String username = etUsername.getText().toString().trim().toLowerCase(Locale.ROOT);
        String password = etPassword.getText().toString();

        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Enter username");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Enter password");
            return;
        }

        try {
            JSONObject usersRoot = getUsersJsonObject();
            if (!usersRoot.has(username)) {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                return;
            }

            JSONObject userObj = usersRoot.getJSONObject(username);
            String salt = userObj.getString("salt");
            String expectedHash = userObj.getString("passwordHash");
            String actualHash = hashPassword(password, salt);

            if (!expectedHash.equals(actualHash)) {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                return;
            }

            currentUsername = username;
            sharedPreferences.edit().putString(KEY_ACTIVE_USER, username).apply();
            clearAuthInputs();
            showDashboard();

        } catch (JSONException e) {
            Toast.makeText(this, "Error reading user data", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean userExists(String username) {
        try {
            return getUsersJsonObject().has(username);
        } catch (JSONException e) {
            return false;
        }
    }

    private JSONObject getUsersJsonObject() throws JSONException {
        String rawJson = sharedPreferences.getString(KEY_USERS_JSON, "{}");
        return new JSONObject(rawJson);
    }

    private String generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    private String hashPassword(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String saltedInput = salt + ":" + password;
            byte[] hashBytes = digest.digest(saltedInput.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(hashBytes, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException e) {
            return "";
        }
    }

    private void clearAuthInputs() {
        etFullName.setText("");
        etUsername.setText("");
        etPassword.setText("");
        etConfirmPassword.setText("");
    }

    // ==================== NAVIGATION & QUIZ FLOW ====================

    private void showAuthScreen() {
        layoutAuth.setVisibility(View.VISIBLE);
        layoutDashboard.setVisibility(View.GONE);
        layoutQuiz.setVisibility(View.GONE);
        layoutResult.setVisibility(View.GONE);
        updateAuthModeUI();
    }

    private void showDashboard() {
        layoutAuth.setVisibility(View.GONE);
        layoutDashboard.setVisibility(View.VISIBLE);
        layoutQuiz.setVisibility(View.GONE);
        layoutResult.setVisibility(View.GONE);

        try {
            JSONObject usersRoot = getUsersJsonObject();
            if (currentUsername != null && usersRoot.has(currentUsername)) {
                JSONObject userObj = usersRoot.getJSONObject(currentUsername);
                String fullName = userObj.optString("fullName", currentUsername);
                int bestPct = userObj.optInt("bestPercentage", 0);
                int played = userObj.optInt("quizzesPlayed", 0);

                tvWelcomeUser.setText("Hello, " + fullName + " (MCA)");
                tvBestScoreStats.setText(String.format(Locale.US,
                        "Best Score: %d%%  •  Modules Completed: %d", bestPct, played));
            }
        } catch (JSONException ignored) {
        }
    }

    private void startQuiz(String category) {
        selectedCategory = category;
        activeQuizQuestions.clear();

        for (Question q : allQuestions) {
            if (CAT_ALL.equals(category) || q.category.equals(category)) {
                activeQuizQuestions.add(q);
            }
        }

        if (activeQuizQuestions.isEmpty()) {
            Toast.makeText(this, "No questions available", Toast.LENGTH_SHORT).show();
            return;
        }

        currentQuestionIndex = 0;
        currentScore = 0;
        answerReviewBuilder = new StringBuilder();

        layoutAuth.setVisibility(View.GONE);
        layoutDashboard.setVisibility(View.GONE);
        layoutResult.setVisibility(View.GONE);
        layoutQuiz.setVisibility(View.VISIBLE);

        displayCurrentQuestion();
    }

    private void displayCurrentQuestion() {
        Question q = activeQuizQuestions.get(currentQuestionIndex);
        int total = activeQuizQuestions.size();

        tvQuizCategory.setText(q.category);
        tvQuestionProgress.setText(String.format(Locale.US, "%d / %d", currentQuestionIndex + 1, total));
        progressBarQuiz.setMax(total);
        progressBarQuiz.setProgress(currentQuestionIndex + 1);

        tvQuestionText.setText(q.questionText);
        rgOptions.clearCheck();
        rbOptionA.setText(q.options[0]);
        rbOptionB.setText(q.options[1]);
        rbOptionC.setText(q.options[2]);
        rbOptionD.setText(q.options[3]);

        if (currentQuestionIndex == total - 1) {
            btnNextQuestion.setText("Submit Final MCA Assessment");
        } else {
            btnNextQuestion.setText("Submit & Next Question");
        }
    }

    private void processAnswerAndAdvance() {
        int checkedId = rgOptions.getCheckedRadioButtonId();
        if (checkedId == -1) {
            Toast.makeText(this, "Please select an answer option", Toast.LENGTH_SHORT).show();
            return;
        }

        int selectedIndex = 0;
        if (checkedId == R.id.rbOptionB) selectedIndex = 1;
        else if (checkedId == R.id.rbOptionC) selectedIndex = 2;
        else if (checkedId == R.id.rbOptionD) selectedIndex = 3;

        Question currentQ = activeQuizQuestions.get(currentQuestionIndex);
        boolean isCorrect = (selectedIndex == currentQ.correctAnswerIndex);
        if (isCorrect) {
            currentScore++;
        }

        answerReviewBuilder.append("Q").append(currentQuestionIndex + 1).append(": ")
                .append(isCorrect ? "✓ Correct" : "✗ Incorrect")
                .append("\nCorrect Answer: ").append(currentQ.options[currentQ.correctAnswerIndex])
                .append("\nExplanation: ").append(currentQ.explanation).append("\n\n");

        currentQuestionIndex++;
        if (currentQuestionIndex < activeQuizQuestions.size()) {
            displayCurrentQuestion();
        } else {
            finishQuizAndSaveStats();
        }
    }

    private void finishQuizAndSaveStats() {
        int total = activeQuizQuestions.size();
        int percentage = (total > 0) ? Math.round((currentScore * 100.0f) / total) : 0;

        try {
            JSONObject usersRoot = getUsersJsonObject();
            if (currentUsername != null && usersRoot.has(currentUsername)) {
                JSONObject userObj = usersRoot.getJSONObject(currentUsername);
                int prevBest = userObj.optInt("bestPercentage", 0);
                int played = userObj.optInt("quizzesPlayed", 0);

                if (percentage > prevBest) {
                    userObj.put("bestPercentage", percentage);
                }
                userObj.put("quizzesPlayed", played + 1);
                usersRoot.put(currentUsername, userObj);
                sharedPreferences.edit().putString(KEY_USERS_JSON, usersRoot.toString()).apply();
            }
        } catch (JSONException ignored) {
        }

        layoutQuiz.setVisibility(View.GONE);
        layoutResult.setVisibility(View.VISIBLE);

        tvResultScore.setText(String.format(Locale.US, "Score: %d / %d (%d%%)", currentScore, total, percentage));
        tvResultSummary.setText(answerReviewBuilder.toString().trim());
    }

    // ==================== MCA CURRICULUM QUESTION BANK ====================

    private void loadMcaQuestionBank() {
        allQuestions.clear();

        // 1. MCA: Advanced Data Structures & Algorithms (5 Questions)
        allQuestions.add(new Question(
                CAT_DS,
                "In an MCA database indexing system using a B-Tree of order m, what is the maximum number of keys a single node can hold?",
                new String[]{"m", "m - 1", "m / 2", "2m - 1"},
                1,
                "A B-Tree node of order m can have at most m children and m - 1 keys."
        ));
        allQuestions.add(new Question(
                CAT_DS,
                "What is the amortized time complexity of performing 'Insert' and 'Extract-Min' operations in a Fibonacci Heap of n nodes?",
                new String[]{
                        "O(1) for Insert and O(log n) for Extract-Min",
                        "O(log n) for both Insert and Extract-Min",
                        "O(n) for Insert and O(1) for Extract-Min",
                        "O(1) for both Insert and Extract-Min"
                },
                0,
                "Fibonacci Heaps support O(1) amortized insertion and O(log n) amortized extract-min, speeding up Dijkstra's algorithm."
        ));
        allQuestions.add(new Question(
                CAT_DS,
                "When resolving hash table collisions using Double Hashing, why must the secondary hash function h2(k) never evaluate to 0?",
                new String[]{
                        "It would cause an infinite probing loop on the same bucket",
                        "It increases memory consumption exponentially",
                        "It converts the hash table into a Red-Black Tree",
                        "Java does not allow modulo operations with prime numbers"
                },
                0,
                "If h2(k) = 0, the step size becomes 0 and every probe checks the exact same index repeatedly."
        ));
        allQuestions.add(new Question(
                CAT_DS,
                "In a Red-Black Tree used in standard library maps (such as Java's TreeMap), which property is strictly enforced?",
                new String[]{
                        "Every simple path from a node to a descendant leaf contains the same number of Black nodes",
                        "Two Red nodes can be adjacent as parent and child",
                        "The root node must always be colored Red",
                        "All leaf (NIL) nodes must be colored Red"
                },
                0,
                "The black-height invariant guarantees balanced tree height within 2*log2(n+1)."
        ));
        allQuestions.add(new Question(
                CAT_DS,
                "Which algorithm fails to find the correct shortest path in a directed graph that contains negative-weight edges?",
                new String[]{"Bellman-Ford Algorithm", "Floyd-Warshall Algorithm", "Dijkstra's Greedy Algorithm", "Johnson's Algorithm"},
                2,
                "Dijkstra's greedy relaxation assumes edge weights are non-negative; Bellman-Ford handles negative weights."
        ));

        // 2. MCA: Android Application Development (5 Questions)
        allQuestions.add(new Question(
                CAT_ANDROID,
                "In Android Jetpack architecture (MVVM), why is ViewModel preferred over saving state directly inside an Activity?",
                new String[]{
                        "ViewModel survives configuration changes such as screen rotations without losing UI data",
                        "ViewModel automatically encrypts SharedPreferences files",
                        "ViewModel replaces the AndroidManifest.xml file",
                        "ViewModel runs exclusively on a separate process"
                },
                0,
                "ViewModel instances are retained across configuration changes until the host Activity is permanently finished."
        ));
        allQuestions.add(new Question(
                CAT_ANDROID,
                "Why is an 'Application Not Responding' (ANR) dialog triggered in an Android application?",
                new String[]{
                        "When the UI (Main) thread is blocked by heavy I/O or network tasks for more than ~5 seconds",
                        "When an Activity uses ConstraintLayout instead of LinearLayout",
                        "When SharedPreferences stores more than 3 keys",
                        "When the device battery drops below 50%"
                },
                0,
                "Blocking the main thread prevents input event dispatching and frame rendering, causing an ANR."
        ));
        allQuestions.add(new Question(
                CAT_ANDROID,
                "Which Android component is specifically designed to share structured local data securely across different applications using URI permissions?",
                new String[]{"BroadcastReceiver", "ContentProvider", "IntentService", "ViewBinding"},
                1,
                "ContentProvider manages access to a central repository of data and enforces inter-app URI permissions."
        ));
        allQuestions.add(new Question(
                CAT_ANDROID,
                "When using a PendingIntent with a notification or alarm in modern Android (API 31+), which mutability flag is required for security?",
                new String[]{
                        "FLAG_IMMUTABLE or FLAG_MUTABLE must be explicitly specified",
                        "FLAG_ACTIVITY_NEW_TASK only",
                        "FLAG_GRANT_READ_URI_PERMISSION only",
                        "No flags are allowed on API 31+"
                },
                0,
                "Android 12+ mandates declaring FLAG_IMMUTABLE (recommended) or FLAG_MUTABLE to prevent intent hijacking."
        ));
        allQuestions.add(new Question(
                CAT_ANDROID,
                "Which modern Jetpack API is the recommended asynchronous replacement for legacy SQLite / SharedPreferences when type safety or coroutines are needed?",
                new String[]{"Jetpack DataStore", "AsyncTask", "LoaderManager", "AIDL"},
                0,
                "Jetpack DataStore (Preferences and Proto) overcomes SharedPreferences' synchronous main-thread pitfalls."
        ));

        // 3. MCA: Cyber Security & Cryptography (5 Questions)
        allQuestions.add(new Question(
                CAT_CYBER,
                "In Public Key Infrastructure (PKI), how does a sender create a verifiable Digital Signature for a message?",
                new String[]{
                        "Hash the message and encrypt the digest using the sender's Private Key",
                        "Encrypt the message using the receiver's Private Key",
                        "Hash the message and encrypt the digest using the receiver's Public Key",
                        "Encode the plaintext message in Base64"
                },
                0,
                "Signing with the sender's private key allows anyone with the sender's public key to verify authenticity and non-repudiation."
        ));
        allQuestions.add(new Question(
                CAT_CYBER,
                "Which vulnerability occurs when a web application accepts a user-supplied URL and fetches it from the backend server, allowing access to internal cloud metadata?",
                new String[]{
                        "Server-Side Request Forgery (SSRF)",
                        "Cross-Site Request Forgery (CSRF)",
                        "Clickjacking",
                        "ARP Cache Poisoning"
                },
                0,
                "SSRF tricks the backend server into making unauthorized HTTP requests to internal-only services."
        ));
        allQuestions.add(new Question(
                CAT_CYBER,
                "In TLS 1.3 handshakes, what security property ensures that recorded encrypted traffic cannot be decrypted in the future even if the server's long-term private key is later compromised?",
                new String[]{
                        "Perfect Forward Secrecy (PFS) via Ephemeral Diffie-Hellman (ECDHE)",
                        "Electronic Codebook (ECB) block mode",
                        "Static RSA key exchange",
                        "MD5 message authentication"
                },
                0,
                "Ephemeral session keys (ECDHE) are discarded after the session, guaranteeing Forward Secrecy."
        ));
        allQuestions.add(new Question(
                CAT_CYBER,
                "What is the primary security advantage of using AES-GCM (Galois/Counter Mode) over AES-CBC?",
                new String[]{
                        "AES-GCM provides Authenticated Encryption with Associated Data (AEAD), ensuring both confidentiality and integrity",
                        "AES-GCM does not require an initialization vector (IV/Nonce)",
                        "AES-GCM uses a 32-bit key size for faster brute forcing",
                        "AES-GCM compresses plaintext before encryption"
                },
                0,
                "AES-GCM computes an authentication tag alongside ciphertext, preventing padding oracle and tampering attacks."
        ));
        allQuestions.add(new Question(
                CAT_CYBER,
                "Which defense mechanism protects web sessions from Cross-Site Request Forgery (CSRF) attacks?",
                new String[]{
                        "Anti-CSRF Synchronizer Tokens combined with SameSite=Strict/Lax cookies",
                        "Using HTTP instead of HTTPS",
                        "Storing session tokens in URL query parameters",
                        "Disabling Content-Security-Policy (CSP)"
                },
                0,
                "Unpredictable CSRF tokens and SameSite cookie attributes prevent malicious third-party sites from forging authenticated requests."
        ));
    }
}